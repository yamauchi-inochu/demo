このファイルは、minoura氏 が、https://gist.github.com/minorua/7654132 で公開している.tsvを加工し作成したものです。
